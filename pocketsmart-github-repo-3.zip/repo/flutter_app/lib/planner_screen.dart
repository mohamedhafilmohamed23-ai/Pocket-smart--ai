import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'gemini_service.dart';
import 'models.dart';

const titles = {'home': 'Home interior planner', 'party': 'Party planner', 'jewelry': 'Jewelry planner'};

class PlannerScreen extends StatefulWidget {
  final String kind;
  const PlannerScreen({super.key, required this.kind});
  @override
  State<PlannerScreen> createState() => _PlannerScreenState();
}

class _PlannerScreenState extends State<PlannerScreen> {
  final _form = GlobalKey<FormState>();
  final budget = TextEditingController();
  final guests = TextEditingController(text: '20');
  final venue = TextEditingController();
  final counts = {
    'lights': TextEditingController(text: '0'),
    'ceiling fans': TextEditingController(text: '0'),
    'dining tables': TextEditingController(text: '0'),
    'sofas': TextEditingController(text: '0'),
  };
  String room = 'Living room', hstyle = 'Modern', event = 'Birthday', occ = 'Wedding', jstyle = 'Traditional';
  Uint8List? image;
  String mime = 'image/jpeg';
  bool loading = false;

  Widget _num(String label, TextEditingController c, {bool req = true}) => Padding(
        padding: const EdgeInsets.only(top: 12),
        child: TextFormField(
          controller: c,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
          validator: (v) {
            final n = num.tryParse(v ?? '');
            if (n == null || n < 0 || (req && n <= 0)) return 'Enter a valid number';
            return null;
          },
        ),
      );

  Widget _dd(String label, String value, List<String> opts, ValueChanged<String> on) => Padding(
        padding: const EdgeInsets.only(top: 12),
        child: DropdownButtonFormField<String>(
          value: value,
          decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
          items: opts.map((o) => DropdownMenuItem(value: o, child: Text(o))).toList(),
          onChanged: (v) {
            if (v != null) setState(() => on(v));
          },
        ),
      );

  Future<void> _pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1200, imageQuality: 85);
    if (x == null) return;
    final bytes = await x.readAsBytes();
    setState(() {
      image = bytes;
      mime = x.mimeType ?? 'image/jpeg';
    });
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    final b = double.parse(budget.text);
    final Map<String, dynamic> d = {'budget': b};
    if (widget.kind == 'home') {
      d['room'] = room;
      d['style'] = hstyle;
      d['items'] = counts.map((k, c) => MapEntry(k, int.tryParse(c.text) ?? 0));
    } else if (widget.kind == 'party') {
      d['event'] = event;
      d['guests'] = int.parse(guests.text);
      d['venue'] = venue.text.isEmpty ? 'a venue of their choice' : venue.text;
    } else {
      d['occasion'] = occ;
      d['style'] = jstyle;
    }
    setState(() => loading = true);
    final plan = await GeminiService.recommend(widget.kind, d, image: image, mime: mime);
    final saved = Map<String, dynamic>.from(d)..remove('items');
    await HistoryStore.add(widget.kind, saved, plan);
    if (!mounted) return;
    setState(() => loading = false);
    Navigator.push(context, MaterialPageRoute(builder: (_) => ResultScreen(title: titles[widget.kind]!, plan: plan)));
  }

  @override
  Widget build(BuildContext context) {
    final k = widget.kind;
    return Scaffold(
      appBar: AppBar(title: Text(titles[k]!)),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          _num('Total budget (INR)', budget),
          if (k == 'home') ...[
            _dd('Room', room, ['Living room', 'Kitchen', 'Bedroom', 'Dining room'], (v) => room = v),
            _dd('Style', hstyle, ['Modern', 'Minimalist', 'Traditional', 'Scandinavian'], (v) => hstyle = v),
            for (final e in counts.entries) _num(e.key[0].toUpperCase() + e.key.substring(1), e.value, req: false),
          ],
          if (k == 'party') ...[
            _dd('Event', event, ['Birthday', 'Corporate', 'Wedding', 'Get-together'], (v) => event = v),
            _num('Guests', guests),
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: TextFormField(
                controller: venue,
                decoration: const InputDecoration(labelText: 'Venue and city', border: OutlineInputBorder()),
              ),
            ),
          ],
          if (k == 'jewelry') ...[
            _dd('Occasion', occ, ['Wedding', 'Festival', 'Office', 'Party'], (v) => occ = v),
            _dd('Style', jstyle, ['Traditional', 'Modern', 'Minimal', 'Statement'], (v) => jstyle = v),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _pick,
              icon: const Icon(Icons.image_outlined),
              label: Text(image == null ? 'Add outfit photo (optional)' : 'Change outfit photo'),
            ),
            if (image != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.memory(image!, height: 160, fit: BoxFit.cover)),
              ),
          ],
          const SizedBox(height: 20),
          FilledButton(
            onPressed: loading ? null : _submit,
            child: loading
                ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Get recommendations'),
          ),
        ]),
      ),
    );
  }
}

class ResultScreen extends StatelessWidget {
  final String title;
  final Plan plan;
  const ResultScreen({super.key, required this.title, required this.plan});

  String _inr(num n) => '\u20B9${n.round().toString().replaceAllMapped(RegExp(r'(\d)(?=(\d\d)+\d(?!\d))'), (m) => '${m[1]},')}';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (plan.usedFallback)
          const Card(
            color: Color(0xFFFDE8E6),
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Text('Could not reach Gemini. Check your API key and internet. Showing default suggestions.'),
            ),
          ),
        Text(plan.summary, style: Theme.of(context).textTheme.bodyLarge),
        const SizedBox(height: 8),
        for (final r in plan.items)
          Card(
            margin: const EdgeInsets.symmetric(vertical: 6),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(r.category, style: Theme.of(context).textTheme.bodySmall),
                Text(r.name, style: Theme.of(context).textTheme.titleMedium),
                Text(_inr(r.price), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Color(0xFFB57C00))),
                const SizedBox(height: 4),
                Text(r.reason),
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton(
                    onPressed: () => launchUrl(Uri.parse(r.link), mode: LaunchMode.externalApplication),
                    child: Text('Find on ${r.platform}'),
                  ),
                ),
              ]),
            ),
          ),
        const SizedBox(height: 8),
        Text('Estimated total: ${_inr(plan.total)}', style: Theme.of(context).textTheme.titleLarge),
        for (final t in plan.tips) Padding(padding: const EdgeInsets.only(top: 6), child: Text('Tip: $t')),
      ]),
    );
  }
}
