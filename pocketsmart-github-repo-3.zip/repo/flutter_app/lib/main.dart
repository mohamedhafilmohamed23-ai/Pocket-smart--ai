import 'package:flutter/material.dart';
import 'models.dart';
import 'planner_screen.dart';

void main() => runApp(const PocketSmartApp());

class PocketSmartApp extends StatelessWidget {
  const PocketSmartApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'PocketSmart AI',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF12302B), secondary: const Color(0xFFE8A317)),
          scaffoldBackgroundColor: const Color(0xFFEEF2F1),
        ),
        home: const HomeScreen(),
      );
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Widget _tile(BuildContext c, String kind, IconData icon, String sub) => Card(
        child: ListTile(
          leading: Icon(icon, size: 32),
          title: Text(titles[kind]!),
          subtitle: Text(sub),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => PlannerScreen(kind: kind))),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('PocketSmart AI'),
          actions: [
            IconButton(
              tooltip: 'History',
              icon: const Icon(Icons.history),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HistoryScreen())),
            ),
          ],
        ),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Text('Plan it within budget.', style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 4),
          const Text('Enter what you can spend and get picks from Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO.'),
          const SizedBox(height: 16),
          _tile(context, 'home', Icons.chair_outlined, 'Room, style and quantities'),
          _tile(context, 'party', Icons.celebration_outlined, 'Guests, event and venue'),
          _tile(context, 'jewelry', Icons.diamond_outlined, 'Occasion, style and outfit photo'),
        ]),
      );
}

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  late Future<List<Map<String, dynamic>>> _f = HistoryStore.all();

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Past plans'), actions: [
          IconButton(
            tooltip: 'Clear history',
            icon: const Icon(Icons.delete_outline),
            onPressed: () async {
              await HistoryStore.clear();
              setState(() => _f = HistoryStore.all());
            },
          ),
        ]),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: _f,
          builder: (c, snap) {
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final list = snap.data!;
            if (list.isEmpty) return const Center(child: Text('No plans yet. Make your first plan from the home screen.'));
            return ListView(children: [
              for (final e in list)
                ListTile(
                  title: Text('${titles[e['kind']] ?? e['kind']}'),
                  subtitle: Text('Budget \u20B9${e['budget']}  |  ${'${e['time']}'.substring(0, 16).replaceAll('T', ' ')}'),
                  onTap: () => Navigator.push(
                    c,
                    MaterialPageRoute(
                      builder: (_) => ResultScreen(
                        title: '${titles[e['kind']] ?? e['kind']}',
                        plan: Plan.fromJson(Map<String, dynamic>.from(e['plan'])),
                      ),
                    ),
                  ),
                ),
            ]);
          },
        ),
      );
}
