import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'models.dart';

// Pass at run time:  flutter run --dart-define=GEMINI_API_KEY=your_key
const _apiKey = String.fromEnvironment('GEMINI_API_KEY');
const _model = String.fromEnvironment('GEMINI_MODEL', defaultValue: 'gemini-2.5-flash');

const _schema = 'Return ONLY JSON: {"summary":"1-2 sentences","items":[{"category":"",'
    '"name":"specific searchable product or service","platform":"Amazon|Flipkart|IKEA|Swiggy|Zomato|OYO",'
    '"price":<INR number>,"reason":"short"}],"total_estimate":<INR number, must not exceed budget>,'
    '"tips":["short tip"]}. 5 to 9 items. All prices in Indian Rupees.';

class GeminiService {
  static String _prompt(String kind, Map<String, dynamic> d, bool hasImage) {
    final head = 'You are PocketSmart AI, a budget-aware planning assistant. Budget: INR ${d['budget']}. ';
    switch (kind) {
      case 'home':
        final items = (d['items'] as Map<String, int>)
            .entries
            .where((e) => e.value > 0)
            .map((e) => '${e.value} ${e.key}')
            .join(', ');
        return '$head Home interior plan for a ${d['room']}, ${d['style']} style. '
            'Wanted: ${items.isEmpty ? 'general essentials' : items}. Prefer IKEA and Amazon '
            '(Flipkart if cheaper); balance function, style and price. $_schema';
      case 'party':
        return '$head Party plan: ${d['event']} for ${d['guests']} guests at ${d['venue']}. '
            'Split the budget across catering, decoration and entertainment (OYO stays only if guests travel). '
            'Swiggy/Zomato for food, Amazon/Flipkart for decor. Use the budget bucket as category. $_schema';
      default:
        return '$head Jewelry plan for a ${d['occasion']}, ${d['style']} style. '
            '${hasImage ? 'The attached photo is the outfit: match its colours and neckline. ' : ''}'
            'Use Amazon and Flipkart. $_schema';
    }
  }

  static String _clean(String t) =>
      t.trim().replaceAll(RegExp(r'^```(?:json)?', multiLine: true), '').replaceAll('```', '').trim();

  static Future<Plan> recommend(String kind, Map<String, dynamic> d,
      {Uint8List? image, String mime = 'image/jpeg'}) async {
    final budget = (d['budget'] as num).toDouble();
    final parts = <Map<String, dynamic>>[];
    if (image != null && kind == 'jewelry') {
      parts.add({'inline_data': {'mime_type': mime, 'data': base64Encode(image)}});
    }
    parts.add({'text': _prompt(kind, d, image != null)});
    try {
      final res = await http
          .post(
            Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$_model:generateContent'),
            headers: {'Content-Type': 'application/json', 'x-goog-api-key': _apiKey},
            body: jsonEncode({
              'contents': [{'parts': parts}],
              'generationConfig': {'responseMimeType': 'application/json', 'temperature': 0.6},
            }),
          )
          .timeout(const Duration(seconds: 60));
      if (res.statusCode != 200) throw Exception('HTTP ${res.statusCode}');
      final text = jsonDecode(res.body)['candidates'][0]['content']['parts'][0]['text'] as String;
      final plan = Plan.fromJson(Map<String, dynamic>.from(jsonDecode(_clean(text))));
      if (plan.items.isEmpty) throw Exception('empty');
      return plan;
    } catch (_) {
      return _fallback(kind, budget);
    }
  }

  // Default suggestions, scaled so they never exceed the budget.
  static Plan _fallback(String kind, double budget) {
    final rows = {
      'home': [['Lighting', 'LED ceiling light warm white', 'Amazon', 1200], ['Furniture', 'Compact dining table 4 seater', 'IKEA', 8000], ['Decor', 'Wall art frame set', 'Amazon', 900], ['Comfort', 'Cushion covers set of 5', 'Flipkart', 500]],
      'party': [['Catering', 'Party food combo for 10', 'Swiggy', 4000], ['Decoration', 'Birthday balloon decoration kit', 'Amazon', 1200], ['Entertainment', 'Bluetooth party speaker', 'Flipkart', 1500], ['Stay', 'Budget hotel rooms', 'OYO', 3000]],
      'jewelry': [['Earrings', 'Oxidised jhumka earrings', 'Flipkart', 400], ['Necklace', 'Kundan choker necklace set', 'Amazon', 900], ['Bangles', 'Gold plated bangles set', 'Amazon', 600]],
    }[kind]!;
    final sum = rows.fold<num>(0, (a, r) => a + (r[3] as num));
    final f = sum > budget ? budget / sum : 1.0;
    final items = rows.map((r) => Rec(r[0] as String, r[1] as String, r[2] as String, ((r[3] as num) * f).round(), 'Popular default pick')).toList();
    return Plan('AI was unavailable, so these are general default suggestions.', items,
        items.fold<num>(0, (a, e) => a + e.price), ['Compare prices across platforms before buying.'],
        usedFallback: true);
  }
}
