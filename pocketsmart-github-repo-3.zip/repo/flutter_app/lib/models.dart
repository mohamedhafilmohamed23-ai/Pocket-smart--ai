import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

const _search = {
  'amazon': 'https://www.amazon.in/s?k=',
  'flipkart': 'https://www.flipkart.com/search?q=',
  'ikea': 'https://www.ikea.com/in/en/search/?q=',
  'swiggy': 'https://www.swiggy.com/search?query=',
  'zomato': 'https://www.zomato.com/search?q=',
  'oyo': 'https://www.oyorooms.com/search/?q=',
};

class Rec {
  final String category, name, platform, reason;
  final num price;
  Rec(this.category, this.name, this.platform, this.price, this.reason);

  String get link =>
      (_search[platform.trim().toLowerCase()] ?? 'https://www.google.com/search?q=') +
      Uri.encodeQueryComponent(name);

  factory Rec.fromJson(Map<String, dynamic> j) => Rec(
        '${j['category'] ?? ''}',
        '${j['name'] ?? ''}',
        '${j['platform'] ?? ''}',
        num.tryParse('${j['price']}') ?? 0,
        '${j['reason'] ?? ''}',
      );

  Map<String, dynamic> toJson() =>
      {'category': category, 'name': name, 'platform': platform, 'price': price, 'reason': reason};
}

class Plan {
  final String summary;
  final List<Rec> items;
  final num total;
  final List<String> tips;
  final bool usedFallback;
  Plan(this.summary, this.items, this.total, this.tips, {this.usedFallback = false});

  factory Plan.fromJson(Map<String, dynamic> j) => Plan(
        '${j['summary'] ?? ''}',
        ((j['items'] ?? []) as List).map((e) => Rec.fromJson(Map<String, dynamic>.from(e))).toList(),
        num.tryParse('${j['total_estimate'] ?? j['total']}') ?? 0,
        ((j['tips'] ?? []) as List).map((e) => '$e').toList(),
        usedFallback: j['fallback'] == true,
      );

  Map<String, dynamic> toJson() => {
        'summary': summary,
        'items': items.map((e) => e.toJson()).toList(),
        'total': total,
        'tips': tips,
        'fallback': usedFallback,
      };
}

/// Saves past plans on the phone (replaces the web app's history table).
class HistoryStore {
  static const _k = 'history';

  static Future<void> add(String kind, Map<String, dynamic> input, Plan plan) async {
    final sp = await SharedPreferences.getInstance();
    final list = sp.getStringList(_k) ?? [];
    list.insert(0, jsonEncode({
      'kind': kind,
      'time': DateTime.now().toIso8601String(),
      'budget': input['budget'],
      'plan': plan.toJson(),
    }));
    await sp.setStringList(_k, list.take(50).toList());
  }

  static Future<List<Map<String, dynamic>>> all() async {
    final sp = await SharedPreferences.getInstance();
    return (sp.getStringList(_k) ?? []).map((s) => Map<String, dynamic>.from(jsonDecode(s))).toList();
  }

  static Future<void> clear() async => (await SharedPreferences.getInstance()).remove(_k);
}
