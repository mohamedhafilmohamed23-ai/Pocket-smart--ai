# PocketSmart AI: Flutter (Android) app

The Android and iOS folders are not included; Flutter generates them for you.

1. Install Flutter: https://docs.flutter.dev/get-started/install
2. Create the project shell, then copy this project's files over it:
   flutter create pocketsmart_ai
   Replace pocketsmart_ai/pubspec.yaml and pocketsmart_ai/lib/ with the ones in this zip.
3. Add internet permission (needed for release builds) in
   android/app/src/main/AndroidManifest.xml, above <application>:
   <uses-permission android:name="android.permission.INTERNET"/>
   and, for opening links on Android 11+, inside <manifest> add:
   <queries><intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent></queries>
4. Get packages:  flutter pub get
5. Run on a phone or emulator:
   flutter run --dart-define=GEMINI_API_KEY=your_key
6. Build an APK:
   flutter build apk --dart-define=GEMINI_API_KEY=your_key

Note: a key built into an app can be extracted from the APK. That is fine for a college demo;
for a real release, call Gemini through your FastAPI backend instead.
