"""AI layer: prompts, Gemini calls (text + optional image), platform links, fallbacks."""
import os, json, re
from urllib.parse import quote_plus
from google import genai
from google.genai import types

MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
_client = None

def _get_client():
    global _client
    if _client is None:
        _client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))
    return _client

# Real search pages on each platform (no private APIs needed).
SEARCH = {
    "amazon": "https://www.amazon.in/s?k=",
    "flipkart": "https://www.flipkart.com/search?q=",
    "ikea": "https://www.ikea.com/in/en/search/?q=",
    "swiggy": "https://www.swiggy.com/search?query=",
    "zomato": "https://www.zomato.com/search?q=",
    "oyo": "https://www.oyorooms.com/search/?q=",
}

def link_for(platform: str, name: str) -> str:
    base = SEARCH.get((platform or "").strip().lower(), "https://www.google.com/search?q=")
    return base + quote_plus(name)

SCHEMA = """Return ONLY valid JSON (no markdown) in this shape:
{"summary": "one or two sentences",
 "items": [{"category": "...", "name": "specific searchable product/service name",
            "platform": "one of: Amazon, Flipkart, IKEA, Swiggy, Zomato, OYO",
            "price": <number in INR>, "reason": "short reason"}],
 "total_estimate": <number in INR>,
 "tips": ["short money-saving tip", "..."]}
Rules: all prices in Indian Rupees (INR). total_estimate must NOT exceed the budget. 5 to 10 items."""

def build_prompt(kind: str, d: dict, has_image: bool) -> str:
    if kind == "home":
        items = ", ".join(f"{q} x {n}" for n, q in d["items"].items() if q) or "general essentials"
        body = (f"Home interior plan. Budget: INR {d['budget']}. Room: {d['room_type']}. "
                f"Style: {d['style']}. Quantities wanted: {items}. "
                "Recommend cost-effective products from IKEA and Amazon (Flipkart if cheaper), "
                "balancing function, style and price.")
    elif kind == "party":
        body = (f"Party plan. Budget: INR {d['budget']}. Guests: {d['guests']}. Event: {d['event_type']}. "
                f"Venue/city: {d['venue']}. Split the budget across catering, decoration and entertainment "
                "(and stay/accommodation via OYO if guests travel). Use Swiggy/Zomato for food, "
                "Amazon/Flipkart for decor. Category should name the budget bucket.")
    else:
        body = (f"Jewelry plan. Budget: INR {d['budget']}. Occasion: {d['occasion']}. Style: {d['style']}. "
                + ("An outfit photo is attached: match colours and neckline. " if has_image else "")
                + "Recommend pieces available on Amazon and Flipkart.")
    return f"You are PocketSmart AI, a budget-aware shopping and planning assistant.\n{body}\n{SCHEMA}"

FALLBACK = {
    "home": [("Lighting", "LED ceiling light warm white", "Amazon", 1200), ("Furniture", "Compact dining table 4 seater", "IKEA", 8000),
             ("Decor", "Wall art frame set", "Amazon", 900), ("Comfort", "Cushion covers set of 5", "Flipkart", 500)],
    "party": [("Catering", "Party food combo for 10", "Swiggy", 4000), ("Decoration", "Birthday balloon decoration kit", "Amazon", 1200),
              ("Entertainment", "Bluetooth party speaker", "Flipkart", 1500), ("Stay", "Budget hotel rooms", "OYO", 3000)],
    "jewelry": [("Earrings", "Oxidised jhumka earrings", "Flipkart", 400), ("Necklace", "Kundan choker necklace set", "Amazon", 900),
                ("Bangles", "Gold plated bangles set", "Amazon", 600)],
}

def _fallback(kind, budget):
    items = [{"category": c, "name": n, "platform": p, "price": pr, "reason": "Popular default pick"} for c, n, p, pr in FALLBACK[kind]]
    total = sum(i["price"] for i in items)
    if total > budget:  # scale prices down so we never exceed the budget
        f = budget / total
        for i in items:
            i["price"] = round(i["price"] * f)
        total = sum(i["price"] for i in items)
    return {"summary": "AI was unavailable, so these are general default suggestions.", "items": items,
            "total_estimate": total, "tips": ["Compare prices across platforms before buying."]}

def _parse(text: str) -> dict:
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    return json.loads(text)

def recommend(kind: str, data: dict, image: bytes = None, mime: str = "image/jpeg") -> dict:
    budget = float(data["budget"])
    contents = [build_prompt(kind, data, bool(image))]
    if image and kind == "jewelry":
        contents.insert(0, types.Part.from_bytes(data=image, mime_type=mime))
    try:
        resp = _get_client().models.generate_content(
            model=MODEL, contents=contents,
            config=types.GenerateContentConfig(response_mime_type="application/json", temperature=0.6))
        result = _parse(resp.text)
        if not result.get("items"):
            raise ValueError("empty result")
    except Exception as e:  # fallback keeps the app usable if AI fails
        print("Gemini error:", e)
        result = _fallback(kind, budget)
    for it in result["items"]:
        it["link"] = link_for(it.get("platform"), it.get("name", ""))
    if float(result.get("total_estimate") or 0) > budget:
        result["tips"] = result.get("tips", []) + ["Estimate is slightly over budget; drop the lowest-priority item."]
    return result
