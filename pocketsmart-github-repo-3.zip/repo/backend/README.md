# PocketSmart AI (FastAPI + Gemini)
1. `pip install -r requirements.txt`
2. Copy `.env.example` to `.env`, add your key from https://aistudio.google.com/apikey
3. `python main.py` then open http://127.0.0.1:8000

Routes: /register /login /logout /dashboard /planner/{home|party|jewelry} /history /session-info
API: POST /generate-home, /generate-party (JSON), /generate-jewelry (multipart with optional image)
