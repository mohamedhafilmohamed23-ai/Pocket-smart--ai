import os, json, sqlite3, hashlib, secrets
from typing import Optional
from fastapi import FastAPI, Request, Form, UploadFile, File
from fastapi.responses import RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
from starlette.concurrency import run_in_threadpool
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()
import gemini_utils as ai  # after load_dotenv so env vars are set

DB = "pocketsmart.db"
app = FastAPI(title="PocketSmart AI")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:8000", "http://127.0.0.1:8000"],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.add_middleware(SessionMiddleware, secret_key=os.getenv("SECRET_KEY", "dev-secret-change-me"))
templates = Jinja2Templates(directory="templates")

# ---------- database ----------
def q(sql, args=(), commit=False):
    con = sqlite3.connect(DB); con.row_factory = sqlite3.Row
    rows = con.execute(sql, args).fetchall()
    if commit: con.commit()
    con.close()
    return rows

@app.on_event("startup")
def startup():
    q("CREATE TABLE IF NOT EXISTS users(username TEXT PRIMARY KEY, password TEXT)", commit=True)
    q("""CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT,
         category TEXT, request TEXT, result TEXT, created TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""", commit=True)

def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(16)
    return salt + "$" + hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 100_000).hex()

def check_pw(pw, stored):
    return secrets.compare_digest(hash_pw(pw, stored.split("$")[0]), stored)

def me(request): return request.session.get("user")

def page(request, name, **ctx):
    return templates.TemplateResponse(request, name, {"user": me(request), **ctx})

def save(user, cat, req, res):
    q("INSERT INTO history(username,category,request,result) VALUES(?,?,?,?)",
      (user, cat, json.dumps(req), json.dumps(res)), commit=True)

# ---------- pages ----------
TITLES = {"home": "Home interior planner", "party": "Party planner", "jewelry": "Jewelry planner"}

@app.get("/")
def index(request: Request): return page(request, "index.html")

@app.get("/register")
def register_page(request: Request): return page(request, "auth.html", mode="register", error=None)

@app.post("/register")
def register(request: Request, username: str = Form(...), password: str = Form(...)):
    username = username.strip()
    if len(username) < 3 or len(password) < 6:
        return page(request, "auth.html", mode="register", error="Username needs 3+ characters and password 6+.")
    if q("SELECT 1 FROM users WHERE username=?", (username,)):
        return page(request, "auth.html", mode="register", error="That username is taken. Try another.")
    q("INSERT INTO users VALUES(?,?)", (username, hash_pw(password)), commit=True)
    request.session["user"] = username
    return RedirectResponse("/dashboard", 303)

@app.get("/login")
def login_page(request: Request): return page(request, "auth.html", mode="login", error=None)

@app.post("/login")
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    row = q("SELECT password FROM users WHERE username=?", (username.strip(),))
    if not row or not check_pw(password, row[0]["password"]):
        return page(request, "auth.html", mode="login", error="Wrong username or password.")
    request.session["user"] = username.strip()
    return RedirectResponse("/dashboard", 303)

@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", 303)

@app.get("/dashboard")
def dashboard(request: Request):
    if not me(request): return RedirectResponse("/login", 303)
    recent = q("SELECT id,category,created FROM history WHERE username=? ORDER BY id DESC LIMIT 5", (me(request),))
    return page(request, "dashboard.html", recent=recent)

@app.get("/planner/{kind}")
def planner(request: Request, kind: str):
    if not me(request): return RedirectResponse("/login", 303)
    if kind not in TITLES: return RedirectResponse("/dashboard", 303)
    return page(request, "planner.html", kind=kind, title=TITLES[kind])

@app.get("/history")
def history(request: Request):
    if not me(request): return RedirectResponse("/login", 303)
    rows = q("SELECT * FROM history WHERE username=? ORDER BY id DESC", (me(request),))
    entries = [{"id": r["id"], "category": r["category"], "created": r["created"],
                "request": json.loads(r["request"]), "result": json.loads(r["result"])} for r in rows]
    return page(request, "history.html", entries=entries)

@app.get("/session-info")
def session_info(request: Request):
    return {"logged_in": bool(me(request)), "user": me(request)}

# ---------- AI endpoints ----------
class HomeIn(BaseModel):
    budget: float = Field(gt=0)
    room_type: str
    style: str = "modern"
    items: dict[str, int] = {}

class PartyIn(BaseModel):
    budget: float = Field(gt=0)
    guests: int = Field(gt=0)
    event_type: str
    venue: str = ""

def need_login(request):
    return None if me(request) else JSONResponse({"error": "Please log in first."}, 401)

@app.post("/generate-home")
async def generate_home(request: Request, body: HomeIn):
    if (r := need_login(request)): return r
    res = await run_in_threadpool(ai.recommend, "home", body.model_dump())
    save(me(request), "home", body.model_dump(), res)
    return {"result": res}

@app.post("/generate-party")
async def generate_party(request: Request, body: PartyIn):
    if (r := need_login(request)): return r
    res = await run_in_threadpool(ai.recommend, "party", body.model_dump())
    save(me(request), "party", body.model_dump(), res)
    return {"result": res}

@app.post("/generate-jewelry")
async def generate_jewelry(request: Request, budget: float = Form(..., gt=0), occasion: str = Form(...),
                           style: str = Form("classic"), image: Optional[UploadFile] = File(None)):
    if (r := need_login(request)): return r
    data = {"budget": budget, "occasion": occasion, "style": style}
    img, mime = None, "image/jpeg"
    if image and image.filename:
        img = await image.read()
        mime = image.content_type or mime
        if len(img) > 5_000_000:
            return JSONResponse({"error": "Image must be under 5 MB."}, 400)
    res = await run_in_threadpool(ai.recommend, "jewelry", data, img, mime)
    save(me(request), "jewelry", data, res)
    return {"result": res}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
